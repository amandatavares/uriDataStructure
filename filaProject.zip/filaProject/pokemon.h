#include <stdio.h>
#include <stdlib.h>

#ifndef POKEMON_H_INCLUDED
#define POKEMON_H_INCLUDED

struct Pokemon {
    char nome[15];
    int cp;
    char tipo[10];
};
typedef struct Pokemon pokemao;

#endif // POKEMON_H_INCLUDED
